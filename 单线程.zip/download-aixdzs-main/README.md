# download-aixdzs

### 爱下电子书爬虫

---
## 实现功能
<ul>
<li>通过bookid下载小说</li>
<li>通过分类序号批量下载小说</li>
<li>邮件推送下载信息，文本附件</li>
<li>注意，使用者请分别在189行和216行输入收件邮箱</li>
<li>作者已经提供了一个临时邮箱用作发送文件，使用者可自行替换发送邮件的账号和密码</li>
</ul>

## 环境需求

<ul>

<li>Python3.4或以上</li>

</ul>

### 依赖包

<ul>

<li>**random**</li>

<li>**request**</li>

<li>**os**</li>

<li>**time**</li>

<li>**sys**</li>

<li>**rich**</li>

</ul>

## 安装依赖包

`pip install -r requirement.txt`

## 免责声明
<ul>
<li>本项目仅用作开源学习，请勿利用本项目进行任何盈利用途，作者不承担任何责任</li>
<ul>
